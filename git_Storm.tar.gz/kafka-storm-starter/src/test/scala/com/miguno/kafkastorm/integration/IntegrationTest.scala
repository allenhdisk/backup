package com.miguno.kafkastorm.integration

import org.scalatest.Tag

object IntegrationTest extends Tag("com.miguno.kafkastorm.integration.IntegrationTest")
