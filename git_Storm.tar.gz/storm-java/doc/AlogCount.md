AlogCountTopology
===