package com.baijian.storm.simple;

import backtype.storm.topology.TopologyBuilder;

/**
 * Author: bj
 * Time: 2013-08-16 3:27 PM
 * Desc: Calculate count of every word in a string, persistent every miniute.
 */
public class WordCountTopology {

    public static void main(String[] args) {
        TopologyBuilder builder = new TopologyBuilder();
    }
}
